document.getElementById('uploadForm').addEventListener('submit', function(e) {
    e.preventDefault();
  
    const formData = new FormData();
    const fileInput = document.getElementById('csvFile');
    const dropOption = document.getElementById('drop_option');
    const missOption = document.getElementById('miss_option');
    const catOption = document.getElementById('cat_option');
    const cat2Option = document.getElementById('cat2_option');
    const colNum = document.getElementById('colNum');
    const splitOption = document.getElementById('split_option');
    const scaleOption = document.getElementById('scale_option');
    const option = document.getElementById('option');
    const outputBox = document.getElementById('outputBox');
    const downloadBtn = document.getElementById('downloadBtn');
    const downloadBtn2 = document.getElementById('downloadBtn2');
    
    formData.append('csvFile', fileInput.files[0]);

    formData.append('option', option.value);

    formData.append('dropOption', dropOption.value);
    formData.append('missOption', missOption.value);
    formData.append('splitOption', splitOption.value);
    formData.append('scaleOption', scaleOption.value);

    if (catOption.value === 'cat1') {
      formData.append('colNum', colNum.value);
    } else {
      formData.append('colNum', -1);
    }
    formData.append('cat2', cat2Option.value);

    const regressionType = document.getElementById('regressionType');
    const classificationType = document.getElementById('classificationType');
    const degreeSelect = document.getElementById('polyreg_deg');
    const critSelect = document.getElementById('dtclass_crit');
    const randomState1Select = document.getElementById('polyreg_rs');
    const randomState2Select = document.getElementById('dtclass_rs');

    if (option.value === 'regression' && regressionType) {
        formData.append('regressionType', regressionType.value);
        // if (regressionType.value === 'r3' && degreeSelect) {
        //   formData.append('polyreg_deg', degreeSelect.value);
        // }
        // if(regressionType.value === 'r3' && randomStateSelect) {
        //   formData.append('polyreg_rs', randomStateSelect.value);
        // }
        if (regressionType.value === 'r3' && degreeSelect && randomState1Select) {
          formData.append('polyreg_deg', degreeSelect.value);
          formData.append('polyreg_rs', randomState1Select.value);
        }
    }

    if (option.value === 'classification' && classificationType) {
        formData.append('classificationType', classificationType.value);
        if (classificationType.value === 'c6' && critSelect && randomState2Select) {
          formData.append('dtclass_crit', critSelect.value);
          formData.append('dtclass_rs', randomState2Select.value);
        }
    }

  
    fetch('http://127.0.0.1:5000/upload', {
      method: 'POST',
      body: formData
    })
    .then(res => res.json())
    .then(data => {
      console.log('Upload success:', data)
      outputBox.textContent = data.result;
        downloadBtn.disabled = false;
        downloadBtn.onclick = () => {
          // window.location.href = data.outputPath;
          window.location.href = 'http://127.0.0.1:5000' + data.modelPath;
        };
        downloadBtn2.disabled = false;
        downloadBtn2.onclick = () => {
          window.location.href = 'http://127.0.0.1:5000' + data.rawFilePath;
        };
        const img = document.getElementById('plotImg');
        img.src = 'http://127.0.0.1:5000' + data.plot_path;
        img.style.display = 'block';
      })
    .catch(err => {
      console.error('Upload error:', err);
      outputBox.textContent = err.error;
      // outputBox.textContent = data.result;
    });
  });


document.addEventListener('DOMContentLoaded', function () {
    const optionSelect = document.getElementById('option');
    const regressionOptions = document.getElementById('regressionOptions');
    const classificationOptions = document.getElementById('classificationOptions');
    const polyregDiv = document.getElementById('polyreg_params');
    const dtclassDiv = document.getElementById('dtclass_params');
    const regressionTypeSelect = document.getElementById('regressionType');
    const classificationTypeSelect = document.getElementById('classificationType');
    const catOptionSelect = document.getElementById('cat_option');
    const colNumDiv = document.getElementById('colNumDiv');

    regressionOptions.classList.add('hidden');
    classificationOptions.classList.add('hidden');
    polyregDiv.classList.add('hidden');
    // colNumDiv.classList.add('hidden');

    optionSelect.addEventListener('change', function () {
      const selected = this.value;
      regressionOptions.classList.add('hidden');
      classificationOptions.classList.add('hidden');
      polyregDiv.classList.add('hidden');
      dtclassDiv.classList.add('hidden');
  
      if (selected === 'regression') {
        regressionOptions.classList.remove('hidden');
        if (regressionTypeSelect.value === 'r3') {
          polyregDiv.classList.remove('hidden');
        }
      } else if (selected === 'classification') {
        classificationOptions.classList.remove('hidden');
        if(classificationTypeSelect.value === 'c6') {
          dtclassDiv.classList.remove('hidden');
        }
      }
    });

    regressionTypeSelect.addEventListener('change', function () {
      if (this.value === 'r3') {
        polyregDiv.classList.remove('hidden');
      } else {
        polyregDiv.classList.add('hidden');
      }
    });

    classificationTypeSelect.addEventListener('change', function () {
      if (this.value === 'c6') {
        dtclassDiv.classList.remove('hidden');
      } else {
        dtclassDiv.classList.add('hidden');
      }
    });

    catOptionSelect.addEventListener('change', function () {
      if (this.value === 'cat1') {
        colNumDiv.classList.remove('hidden');
      } else {
        colNumDiv.classList.add('hidden');
      }
    });


  });