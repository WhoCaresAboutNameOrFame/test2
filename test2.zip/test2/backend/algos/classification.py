import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.naive_bayes import GaussianNB
from sklearn.ensemble import RandomForestClassifier

import os
import joblib



# logistic regression
def func_logisticRegression(filepath, PROCESSED_FOLDER):
    dataset = pd.read_csv(filepath)
    X = dataset.iloc[:, :-1].values
    y = dataset.iloc[:, -1].value

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.25, random_state = 0)
    
    sc = StandardScaler()
    X_train = sc.fit_transform(X_train)
    X_test = sc.transform(X_test)

    classifier = LogisticRegression(random_state = 0)
    classifier.fit(X_train, y_train)

    output_path = os.path.join(PROCESSED_FOLDER, 'c1_model.joblib')
    joblib.dump(classifier, output_path)

    output_path2 = os.path.join(PROCESSED_FOLDER, 'c1.py')
    with open(output_path2, "w") as f:
        f.write("""
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
import os
import joblib
                                
dataset = pd.read_csv(filepath)
X = dataset.iloc[:, :-1].values
y = dataset.iloc[:, -1].value

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.25, random_state = 0)

sc = StandardScaler()
X_train = sc.fit_transform(X_train)
X_test = sc.transform(X_test)

classifier = LogisticRegression(random_state = 0)
classifier.fit(X_train, y_train)

output_path = os.path.join(PROCESSED_FOLDER, 'c1_model.joblib')
joblib.dump(classifier, output_path)
                """)

    return [output_path, output_path2]


# knn
def func_kNearestNeighbors(filepath, PROCESSED_FOLDER):
    dataset = pd.read_csv(filepath)
    X = dataset.iloc[:, :-1].values
    y = dataset.iloc[:, -1].values

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.25, random_state = 0)

    sc = StandardScaler()
    X_train = sc.fit_transform(X_train)
    X_test = sc.transform(X_test)

    classifier = KNeighborsClassifier(n_neighbors = 5, metric = 'minkowski', p = 2)
    classifier.fit(X_train, y_train)

    output_path = os.path.join(PROCESSED_FOLDER, 'c2_model.joblib')
    joblib.dump(classifier, output_path)

    output_path2 = os.path.join(PROCESSED_FOLDER, 'c2.py')
    with open(output_path2, "w") as f:
        f.write("""
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
import os
import joblib
                
dataset = pd.read_csv(filepath)
X = dataset.iloc[:, :-1].values
y = dataset.iloc[:, -1].values

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.25, random_state = 0)

sc = StandardScaler()
X_train = sc.fit_transform(X_train)
X_test = sc.transform(X_test)

classifier = KNeighborsClassifier(n_neighbors = 5, metric = 'minkowski', p = 2)
classifier.fit(X_train, y_train)

output_path = os.path.join(PROCESSED_FOLDER, 'c2_model.joblib')
joblib.dump(classifier, output_path)
                """)

    return [output_path, output_path2]


#svm
def func_supportVectorMachine(filepath, PROCESSED_FOLDER):
    dataset = pd.read_csv(filepath)
    X = dataset.iloc[:, :-1].values
    y = dataset.iloc[:, -1].values

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.25, random_state = 0)

    sc = StandardScaler()
    X_train = sc.fit_transform(X_train)
    X_test = sc.transform(X_test)

    classifier = SVC(kernel = 'linear', random_state = 0)
    classifier.fit(X_train, y_train)

    output_path = os.path.join(PROCESSED_FOLDER, 'c3_model.joblib')
    joblib.dump(classifier, output_path)

    output_path2 = os.path.join(PROCESSED_FOLDER, 'c3.py')
    with open(output_path2, "w") as f:
        f.write("""
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
import os
import joblib
                
dataset = pd.read_csv(filepath)
X = dataset.iloc[:, :-1].values
y = dataset.iloc[:, -1].values

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.25, random_state = 0)

sc = StandardScaler()
X_train = sc.fit_transform(X_train)
X_test = sc.transform(X_test)

classifier = SVC(kernel = 'linear', random_state = 0)
classifier.fit(X_train, y_train)

output_path = os.path.join(PROCESSED_FOLDER, 'c3_model.joblib')
joblib.dump(classifier, output_path)
                """)

    return [output_path, output_path2]


# kernel svm
def func_kernelSupportVectorMachine(filepath, PROCESSED_FOLDER):
    dataset = pd.read_csv(filepath)
    X = dataset.iloc[:, :-1].values
    y = dataset.iloc[:, -1].values

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.25, random_state = 0)

    sc = StandardScaler()
    X_train = sc.fit_transform(X_train)
    X_test = sc.transform(X_test)

    classifier = SVC(kernel = 'rbf', random_state = 0)
    classifier.fit(X_train, y_train)

    output_path = os.path.join(PROCESSED_FOLDER, 'c4_model.joblib')
    joblib.dump(classifier, output_path)

    output_path2 = os.path.join(PROCESSED_FOLDER, 'c4.py')
    with open(output_path2, "w") as f:
        f.write("""
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
import os
import joblib

dataset = pd.read_csv(filepath)
X = dataset.iloc[:, :-1].values
y = dataset.iloc[:, -1].values

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.25, random_state = 0)

sc = StandardScaler()
X_train = sc.fit_transform(X_train)
X_test = sc.transform(X_test)

classifier = SVC(kernel = 'rbf', random_state = 0)
classifier.fit(X_train, y_train)

output_path = os.path.join(PROCESSED_FOLDER, 'c4_model.joblib')
joblib.dump(classifier, output_path)                
                """)

    return [output_path, output_path2]


# naive bayes
def func_naiveBayes(filepath, PROCESSED_FOLDER):
    dataset = pd.read_csv(filepath)
    X = dataset.iloc[:, :-1].values
    y = dataset.iloc[:, -1].values

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.25, random_state = 0)

    sc = StandardScaler()
    X_train = sc.fit_transform(X_train)
    X_test = sc.transform(X_test)

    classifier = GaussianNB()
    classifier.fit(X_train, y_train)

    output_path = os.path.join(PROCESSED_FOLDER, 'c5_model.joblib')
    joblib.dump(classifier, output_path)

    output_path2 = os.path.join(PROCESSED_FOLDER, 'c5.py')
    with open(output_path2, "w") as f:
        f.write("""
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
import os
import joblib
                
dataset = pd.read_csv(filepath)
X = dataset.iloc[:, :-1].values
y = dataset.iloc[:, -1].values

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.25, random_state = 0)

sc = StandardScaler()
X_train = sc.fit_transform(X_train)
X_test = sc.transform(X_test)

classifier = GaussianNB()
classifier.fit(X_train, y_train)

output_path = os.path.join(PROCESSED_FOLDER, 'c5_model.joblib')
joblib.dump(classifier, output_path)
                """)

    return [output_path, output_path2]


# decision tree classification
def func_decisionTreeClassifier(filepath, PROCESSED_FOLDER):
    dataset = pd.read_csv(filepath)
    X = dataset.iloc[:, :-1].values
    y = dataset.iloc[:, -1].values

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.25, random_state = 0)

    sc = StandardScaler()
    X_train = sc.fit_transform(X_train)
    X_test = sc.transform(X_test)

    classifier = DecisionTreeClassifier(criterion = 'entropy', random_state = 0)
    classifier.fit(X_train, y_train)

    output_path = os.path.join(PROCESSED_FOLDER, 'c6_model.joblib')
    joblib.dump(classifier, output_path)

    output_path2 = os.path.join(PROCESSED_FOLDER, 'c6.py')
    with open(output_path2, "w") as f:
        f.write("""
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
import os
import joblib
                
dataset = pd.read_csv(filepath)
X = dataset.iloc[:, :-1].values
y = dataset.iloc[:, -1].values

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.25, random_state = 0)

sc = StandardScaler()
X_train = sc.fit_transform(X_train)
X_test = sc.transform(X_test)

classifier = DecisionTreeClassifier(criterion = 'entropy', random_state = 0)
classifier.fit(X_train, y_train)

output_path = os.path.join(PROCESSED_FOLDER, 'c6_model.joblib')
joblib.dump(classifier, output_path)
                """)

    return [output_path, output_path2]

# random forest classification
def func_randomForestClassifier(filepath, PROCESSED_FOLDER):
    dataset = pd.read_csv(filepath)
    X = dataset.iloc[:, :-1].values
    y = dataset.iloc[:, -1].values

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.25, random_state = 0)

    sc = StandardScaler()
    X_train = sc.fit_transform(X_train)
    X_test = sc.transform(X_test)

    classifier = RandomForestClassifier(n_estimators = 10, criterion = 'entropy', random_state = 0)
    classifier.fit(X_train, y_train)

    output_path = os.path.join(PROCESSED_FOLDER, 'c7_model.joblib')
    joblib.dump(classifier, output_path)

    output_path2 = os.path.join(PROCESSED_FOLDER, 'c7.py')
    with open(output_path2, "w") as f:
        f.write("""
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
import os
import joblib
                
dataset = pd.read_csv(filepath)
X = dataset.iloc[:, :-1].values
y = dataset.iloc[:, -1].values

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.25, random_state = 0)

sc = StandardScaler()
X_train = sc.fit_transform(X_train)
X_test = sc.transform(X_test)

classifier = RandomForestClassifier(n_estimators = 10, criterion = 'entropy', random_state = 0)
classifier.fit(X_train, y_train)

output_path = os.path.join(PROCESSED_FOLDER, 'c7_model.joblib')
joblib.dump(classifier, output_path)
                """)

    return [output_path, output_path2]