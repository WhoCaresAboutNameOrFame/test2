from flask import Flask, request, send_file, jsonify, send_from_directory
import os
import pandas as pd
from flask_cors import CORS
from algos import regression
from algos import classification

from pymongo import MongoClient
import gridfs
import certifi
from pymongo.server_api import ServerApi

app = Flask(__name__)
CORS(app)

UPLOAD_FOLDER = 'uploads'
PROCESSED_FOLDER = "D:\\buffer_\\uploads"

# uri = "mongodb+srv://pranithdutta26:Q84QjuGMYnsiqdvU@users.gcqvzvl.mongodb.net/?retryWrites=true&w=majority&appName=Users"
# client = MongoClient(uri, server_api=ServerApi('1'), tlsCAFile=certifi.where())
# db = client["test1"]
# fs = gridfs.GridFS(db)

# os.makedirs(UPLOAD_FOLDER, exist_ok=True)
# os.makedirs(PROCESSED_FOLDER, exist_ok=True)

@app.route('/upload', methods=['POST'])
def upload():
    try:        
        file = request.files['csvFile']
        dropNum = request.form.get('dropNum')

        colNum = int(request.form.get('colNum'))
        option = request.form.get('option')
        optionType = 'lol'

        if not file:
            return jsonify({'error': 'No file uploaded'}), 400

        # file_id = fs.put(file, filename=file.filename, content_type='text/csv')
        # print(f"CSV uploaded successfully! File ID: {file_id}")
        # file.seek(0)

        output_path = 'ans'
        if option == 'regression':
            optionType = request.form.get('regressionType')
        elif option == 'classification':
            optionType = request.form.get('classificationType')
        print(optionType)

        arr = [file, PROCESSED_FOLDER]
               
        # arr.append(int(dropNum[-1]))
        if dropNum == 'drop0':
            arr.append(0)
        else:
            arr.append(1)

        arr.append(colNum)

        if option == 'regression':
            if optionType == 'r1':
                output_path = regression.func_linearRegression(file, PROCESSED_FOLDER)
            elif optionType == 'r2':
                output_path = regression.func_multipleLinearRegression(file, PROCESSED_FOLDER)
            elif optionType == 'r3':
                deg = int(request.form.get('polyreg_deg')[-1])
                rs = int(request.form.get('polyreg_rs')[-1])
                if rs!=0:
                    rs = 42
                arr.append(deg)
                arr.append(rs)
                # output_path = regression.func_polynomialRegression(file, PROCESSED_FOLDER)
                output_path = regression.func_polynomialRegression(arr)
            elif optionType == 'r4':
                output_path = regression.func_svr(file, PROCESSED_FOLDER)
            elif optionType == 'r5':
                output_path = regression.func_decisionTreeRegression(file, PROCESSED_FOLDER)
            else:
                output_path = regression.func_randomForestRegression(file, PROCESSED_FOLDER)
            
        elif option == 'classification':
            if optionType == 'c1':
                output_path = classification.func_logisticRegression(file, PROCESSED_FOLDER)
            elif optionType == 'c2':
                output_path = classification.func_kNearestNeighbors(file, PROCESSED_FOLDER)
            elif optionType == 'c3':
                output_path = classification.func_supportVectorMachine(file, PROCESSED_FOLDER)
            elif optionType == 'c4':
                output_path = classification.func_kernelSupportVectorMachine(file, PROCESSED_FOLDER)
            elif optionType == 'c5':
                output_path = classification.func_naiveBayes(file, PROCESSED_FOLDER)
            elif optionType == 'c6':
                output_path = classification.func_decisionTreeClassifier(file, PROCESSED_FOLDER)
            else:
                output_path = classification.func_randomForestClassifier(file, PROCESSED_FOLDER)
            
        else:
            output_path = 'dorime'
        modelPath = output_path[0]
        rawFilePath = output_path[1]
        result = output_path[2]
        plotPath = output_path[3]


        # print(output_path)
        # output_path = os.path.join(PROCESSED_FOLDER, 'processed.json')

        return jsonify({'message': 'File processed',
                        'modelPath': f'/download/{os.path.basename(modelPath)}',
                        'rawFilePath': f'/download/{os.path.basename(rawFilePath)}',
                        'result': result,
                        'plot_path' : f'/plot/{os.path.basename(plotPath)}'
                        }), 200
        # return jsonify({'message': 'File processed', 'outputPath': output_path}), 200
    except Exception as e:
        print(f"Error processing request: {e}")
        return jsonify({'error': str(e), 'message':'An error occurred on the server.'}), 500 #return an error code and message.


@app.route('/download/<filename>')
def download(filename):
    print('download')
    path = os.path.join(PROCESSED_FOLDER, filename)
    if not os.path.exists(path):
        return jsonify({"error": "File not found"}), 404
    # return send_file(path, as_attachment=True)
    return send_from_directory(PROCESSED_FOLDER, filename, as_attachment=True)

@app.route('/plot/<filename>')
def serve_plot(filename):
    return send_from_directory(PROCESSED_FOLDER, filename, mimetype='image/png')

if __name__ == '__main__':
    app.run(debug=True)
